from django.apps import AppConfig


class FoodItemsConfig(AppConfig):
    name = 'food_items'
