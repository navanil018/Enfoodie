from django.apps import AppConfig


class FoodAreaConfig(AppConfig):
    name = 'food_area'
