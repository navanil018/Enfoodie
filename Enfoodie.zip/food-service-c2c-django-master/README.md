# A web application (C2C) for delivery of hygienic foods from home to the clients.
* Live: https://food-service-c2c.herokuapp.com/

## Install and active virtual-environment by command:
* pip install virtualenv
* virtualenv your_environment_name
* active

## Install all the requirements by command:
* pip install -r requirements.txt

## Homepage:
![foodservice ui](https://user-images.githubusercontent.com/23103980/49749826-7a99d100-fcd3-11e8-9b59-569323d6ebf3.png)
